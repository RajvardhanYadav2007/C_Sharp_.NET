﻿
namespace Windows_Tools_Assignment_5
{
    partial class frm_Use_CheckBox_CheckListBox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Employ_Registretion_System = new System.Windows.Forms.Panel();
            this.lbl_Employ_Registretion_System = new System.Windows.Forms.Label();
            this.lbl_Employe_Name = new System.Windows.Forms.Label();
            this.lbl_Department = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_Hobbies = new System.Windows.Forms.Label();
            this.tb_Employe_Name = new System.Windows.Forms.TextBox();
            this.cmb_Department = new System.Windows.Forms.ComboBox();
            this.gb_Gender = new System.Windows.Forms.GroupBox();
            this.rb_Female = new System.Windows.Forms.RadioButton();
            this.rb_Male = new System.Windows.Forms.RadioButton();
            this.lbl_Known_Languages = new System.Windows.Forms.Label();
            this.btn_Submit = new System.Windows.Forms.Button();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.lbl_Output = new System.Windows.Forms.Label();
            this.tb_Output = new System.Windows.Forms.TextBox();
            this.clb_Hobbies = new System.Windows.Forms.CheckedListBox();
            this.cb_Marathi = new System.Windows.Forms.CheckBox();
            this.cb_Hindi = new System.Windows.Forms.CheckBox();
            this.cb_French = new System.Windows.Forms.CheckBox();
            this.cb_English = new System.Windows.Forms.CheckBox();
            this.gb_Known_Languages = new System.Windows.Forms.GroupBox();
            this.pnl_Employ_Registretion_System.SuspendLayout();
            this.gb_Gender.SuspendLayout();
            this.gb_Known_Languages.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Employ_Registretion_System
            // 
            this.pnl_Employ_Registretion_System.BackColor = System.Drawing.Color.SeaGreen;
            this.pnl_Employ_Registretion_System.Controls.Add(this.lbl_Employ_Registretion_System);
            this.pnl_Employ_Registretion_System.Location = new System.Drawing.Point(5, 2);
            this.pnl_Employ_Registretion_System.Name = "pnl_Employ_Registretion_System";
            this.pnl_Employ_Registretion_System.Size = new System.Drawing.Size(1309, 82);
            this.pnl_Employ_Registretion_System.TabIndex = 0;
            // 
            // lbl_Employ_Registretion_System
            // 
            this.lbl_Employ_Registretion_System.AutoSize = true;
            this.lbl_Employ_Registretion_System.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employ_Registretion_System.ForeColor = System.Drawing.Color.White;
            this.lbl_Employ_Registretion_System.Location = new System.Drawing.Point(383, 29);
            this.lbl_Employ_Registretion_System.Name = "lbl_Employ_Registretion_System";
            this.lbl_Employ_Registretion_System.Size = new System.Drawing.Size(557, 35);
            this.lbl_Employ_Registretion_System.TabIndex = 0;
            this.lbl_Employ_Registretion_System.Text = "EMPLOYEE REGISTRESION SYSTEM";
            this.lbl_Employ_Registretion_System.Click += new System.EventHandler(this.lbl_Employ_Registretion_System_Click);
            // 
            // lbl_Employe_Name
            // 
            this.lbl_Employe_Name.AutoSize = true;
            this.lbl_Employe_Name.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employe_Name.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Employe_Name.Location = new System.Drawing.Point(307, 142);
            this.lbl_Employe_Name.Name = "lbl_Employe_Name";
            this.lbl_Employe_Name.Size = new System.Drawing.Size(144, 22);
            this.lbl_Employe_Name.TabIndex = 1;
            this.lbl_Employe_Name.Text = "Employe Name";
            // 
            // lbl_Department
            // 
            this.lbl_Department.AutoSize = true;
            this.lbl_Department.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Department.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Department.Location = new System.Drawing.Point(307, 209);
            this.lbl_Department.Name = "lbl_Department";
            this.lbl_Department.Size = new System.Drawing.Size(116, 22);
            this.lbl_Department.TabIndex = 2;
            this.lbl_Department.Text = "Department";
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Gender.Location = new System.Drawing.Point(307, 268);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(74, 22);
            this.lbl_Gender.TabIndex = 3;
            this.lbl_Gender.Text = "Gender";
            // 
            // lbl_Hobbies
            // 
            this.lbl_Hobbies.AutoSize = true;
            this.lbl_Hobbies.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Hobbies.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Hobbies.Location = new System.Drawing.Point(307, 461);
            this.lbl_Hobbies.Name = "lbl_Hobbies";
            this.lbl_Hobbies.Size = new System.Drawing.Size(81, 22);
            this.lbl_Hobbies.TabIndex = 4;
            this.lbl_Hobbies.Text = "Hobbies";
            // 
            // tb_Employe_Name
            // 
            this.tb_Employe_Name.Location = new System.Drawing.Point(508, 142);
            this.tb_Employe_Name.Multiline = true;
            this.tb_Employe_Name.Name = "tb_Employe_Name";
            this.tb_Employe_Name.Size = new System.Drawing.Size(524, 39);
            this.tb_Employe_Name.TabIndex = 5;
            // 
            // cmb_Department
            // 
            this.cmb_Department.FormattingEnabled = true;
            this.cmb_Department.Location = new System.Drawing.Point(508, 207);
            this.cmb_Department.Name = "cmb_Department";
            this.cmb_Department.Size = new System.Drawing.Size(524, 24);
            this.cmb_Department.TabIndex = 6;
            // 
            // gb_Gender
            // 
            this.gb_Gender.Controls.Add(this.rb_Female);
            this.gb_Gender.Controls.Add(this.rb_Male);
            this.gb_Gender.Location = new System.Drawing.Point(508, 254);
            this.gb_Gender.Name = "gb_Gender";
            this.gb_Gender.Size = new System.Drawing.Size(523, 59);
            this.gb_Gender.TabIndex = 7;
            this.gb_Gender.TabStop = false;
            this.gb_Gender.Text = "Gender";
            // 
            // rb_Female
            // 
            this.rb_Female.AutoSize = true;
            this.rb_Female.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold);
            this.rb_Female.ForeColor = System.Drawing.Color.Blue;
            this.rb_Female.Location = new System.Drawing.Point(333, 21);
            this.rb_Female.Name = "rb_Female";
            this.rb_Female.Size = new System.Drawing.Size(81, 29);
            this.rb_Female.TabIndex = 0;
            this.rb_Female.TabStop = true;
            this.rb_Female.Text = "Female";
            this.rb_Female.UseVisualStyleBackColor = true;
            // 
            // rb_Male
            // 
            this.rb_Male.AutoSize = true;
            this.rb_Male.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold);
            this.rb_Male.ForeColor = System.Drawing.Color.Blue;
            this.rb_Male.Location = new System.Drawing.Point(83, 21);
            this.rb_Male.Name = "rb_Male";
            this.rb_Male.Size = new System.Drawing.Size(66, 29);
            this.rb_Male.TabIndex = 0;
            this.rb_Male.TabStop = true;
            this.rb_Male.Text = "Male";
            this.rb_Male.UseVisualStyleBackColor = true;
            // 
            // lbl_Known_Languages
            // 
            this.lbl_Known_Languages.AutoSize = true;
            this.lbl_Known_Languages.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Known_Languages.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Known_Languages.Location = new System.Drawing.Point(307, 323);
            this.lbl_Known_Languages.Name = "lbl_Known_Languages";
            this.lbl_Known_Languages.Size = new System.Drawing.Size(175, 22);
            this.lbl_Known_Languages.TabIndex = 3;
            this.lbl_Known_Languages.Text = "Known Languages";
            // 
            // btn_Submit
            // 
            this.btn_Submit.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_Submit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Submit.Location = new System.Drawing.Point(510, 600);
            this.btn_Submit.Name = "btn_Submit";
            this.btn_Submit.Size = new System.Drawing.Size(111, 33);
            this.btn_Submit.TabIndex = 10;
            this.btn_Submit.Text = "Submit";
            this.btn_Submit.UseVisualStyleBackColor = false;
            this.btn_Submit.Click += new System.EventHandler(this.btn_Submit_Click);
            // 
            // btn_Reset
            // 
            this.btn_Reset.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_Reset.Location = new System.Drawing.Point(662, 600);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(111, 33);
            this.btn_Reset.TabIndex = 10;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = false;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // lbl_Output
            // 
            this.lbl_Output.AutoSize = true;
            this.lbl_Output.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Output.ForeColor = System.Drawing.Color.Green;
            this.lbl_Output.Location = new System.Drawing.Point(307, 669);
            this.lbl_Output.Name = "lbl_Output";
            this.lbl_Output.Size = new System.Drawing.Size(71, 22);
            this.lbl_Output.TabIndex = 4;
            this.lbl_Output.Text = "Output";
            this.lbl_Output.Click += new System.EventHandler(this.lbl_Output_Click);
            // 
            // tb_Output
            // 
            this.tb_Output.Location = new System.Drawing.Point(508, 669);
            this.tb_Output.Multiline = true;
            this.tb_Output.Name = "tb_Output";
            this.tb_Output.Size = new System.Drawing.Size(524, 39);
            this.tb_Output.TabIndex = 5;
            // 
            // clb_Hobbies
            // 
            this.clb_Hobbies.FormattingEnabled = true;
            this.clb_Hobbies.Items.AddRange(new object[] {
            "Programming",
            "Coding",
            "Reading",
            "typing"});
            this.clb_Hobbies.Location = new System.Drawing.Point(508, 465);
            this.clb_Hobbies.Name = "clb_Hobbies";
            this.clb_Hobbies.Size = new System.Drawing.Size(265, 72);
            this.clb_Hobbies.TabIndex = 11;
            this.clb_Hobbies.SelectedIndexChanged += new System.EventHandler(this.clb_Hobbies_SelectedIndexChanged);
            // 
            // cb_Marathi
            // 
            this.cb_Marathi.AutoSize = true;
            this.cb_Marathi.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Marathi.ForeColor = System.Drawing.Color.Blue;
            this.cb_Marathi.Location = new System.Drawing.Point(83, 21);
            this.cb_Marathi.Name = "cb_Marathi";
            this.cb_Marathi.Size = new System.Drawing.Size(86, 29);
            this.cb_Marathi.TabIndex = 0;
            this.cb_Marathi.Text = "Marathi";
            this.cb_Marathi.UseVisualStyleBackColor = true;
            this.cb_Marathi.CheckedChanged += new System.EventHandler(this.cb_Marathi_CheckedChanged);
            // 
            // cb_Hindi
            // 
            this.cb_Hindi.AutoSize = true;
            this.cb_Hindi.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_Hindi.ForeColor = System.Drawing.Color.Blue;
            this.cb_Hindi.Location = new System.Drawing.Point(83, 53);
            this.cb_Hindi.Name = "cb_Hindi";
            this.cb_Hindi.Size = new System.Drawing.Size(70, 29);
            this.cb_Hindi.TabIndex = 0;
            this.cb_Hindi.Text = "Hindi";
            this.cb_Hindi.UseVisualStyleBackColor = true;
            this.cb_Hindi.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // cb_French
            // 
            this.cb_French.AutoSize = true;
            this.cb_French.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_French.ForeColor = System.Drawing.Color.Blue;
            this.cb_French.Location = new System.Drawing.Point(83, 80);
            this.cb_French.Name = "cb_French";
            this.cb_French.Size = new System.Drawing.Size(78, 29);
            this.cb_French.TabIndex = 0;
            this.cb_French.Text = "French";
            this.cb_French.UseVisualStyleBackColor = true;
            this.cb_French.CheckedChanged += new System.EventHandler(this.cb_French_CheckedChanged);
            // 
            // cb_English
            // 
            this.cb_English.AutoSize = true;
            this.cb_English.Font = new System.Drawing.Font("Myanmar Text", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_English.ForeColor = System.Drawing.Color.Blue;
            this.cb_English.Location = new System.Drawing.Point(83, 107);
            this.cb_English.Name = "cb_English";
            this.cb_English.Size = new System.Drawing.Size(80, 29);
            this.cb_English.TabIndex = 0;
            this.cb_English.Text = "English";
            this.cb_English.UseVisualStyleBackColor = true;
            this.cb_English.CheckedChanged += new System.EventHandler(this.cb_English_CheckedChanged);
            // 
            // gb_Known_Languages
            // 
            this.gb_Known_Languages.Controls.Add(this.cb_English);
            this.gb_Known_Languages.Controls.Add(this.cb_French);
            this.gb_Known_Languages.Controls.Add(this.cb_Hindi);
            this.gb_Known_Languages.Controls.Add(this.cb_Marathi);
            this.gb_Known_Languages.Location = new System.Drawing.Point(508, 323);
            this.gb_Known_Languages.Name = "gb_Known_Languages";
            this.gb_Known_Languages.Size = new System.Drawing.Size(265, 133);
            this.gb_Known_Languages.TabIndex = 8;
            this.gb_Known_Languages.TabStop = false;
            this.gb_Known_Languages.Text = "Known Languages";
            this.gb_Known_Languages.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // frm_Use_CheckBox_CheckListBox
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1320, 727);
            this.Controls.Add(this.clb_Hobbies);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn_Submit);
            this.Controls.Add(this.gb_Known_Languages);
            this.Controls.Add(this.gb_Gender);
            this.Controls.Add(this.cmb_Department);
            this.Controls.Add(this.tb_Output);
            this.Controls.Add(this.tb_Employe_Name);
            this.Controls.Add(this.lbl_Output);
            this.Controls.Add(this.lbl_Hobbies);
            this.Controls.Add(this.lbl_Known_Languages);
            this.Controls.Add(this.lbl_Gender);
            this.Controls.Add(this.lbl_Department);
            this.Controls.Add(this.lbl_Employe_Name);
            this.Controls.Add(this.pnl_Employ_Registretion_System);
            this.Name = "frm_Use_CheckBox_CheckListBox";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Use CheckBox CheckListBox";
            this.Load += new System.EventHandler(this.frm_Use_CheckBox_CheckListBox_Load);
            this.pnl_Employ_Registretion_System.ResumeLayout(false);
            this.pnl_Employ_Registretion_System.PerformLayout();
            this.gb_Gender.ResumeLayout(false);
            this.gb_Gender.PerformLayout();
            this.gb_Known_Languages.ResumeLayout(false);
            this.gb_Known_Languages.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Employ_Registretion_System;
        private System.Windows.Forms.Label lbl_Employ_Registretion_System;
        private System.Windows.Forms.Label lbl_Employe_Name;
        private System.Windows.Forms.Label lbl_Department;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_Hobbies;
        private System.Windows.Forms.TextBox tb_Employe_Name;
        private System.Windows.Forms.ComboBox cmb_Department;
        private System.Windows.Forms.GroupBox gb_Gender;
        private System.Windows.Forms.Label lbl_Known_Languages;
        private System.Windows.Forms.Button btn_Submit;
        private System.Windows.Forms.Button btn_Reset;
        private System.Windows.Forms.Label lbl_Output;
        private System.Windows.Forms.TextBox tb_Output;
        private System.Windows.Forms.RadioButton rb_Female;
        private System.Windows.Forms.RadioButton rb_Male;
        private System.Windows.Forms.CheckedListBox clb_Hobbies;
        private System.Windows.Forms.CheckBox cb_Marathi;
        private System.Windows.Forms.CheckBox cb_Hindi;
        private System.Windows.Forms.CheckBox cb_French;
        private System.Windows.Forms.CheckBox cb_English;
        private System.Windows.Forms.GroupBox gb_Known_Languages;
    }
}