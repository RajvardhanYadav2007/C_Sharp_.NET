﻿
namespace Windows_Tools_Assignment_5
{
    partial class frm_Windows_Tools
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_ = new System.Windows.Forms.Panel();
            this.lbl_Shri_Ram_Mechanics = new System.Windows.Forms.Label();
            this.lbl_Employe_Name = new System.Windows.Forms.Label();
            this.lbl_Department = new System.Windows.Forms.Label();
            this.lbl_Gender = new System.Windows.Forms.Label();
            this.lbl_Preferred_Shift = new System.Windows.Forms.Label();
            this.tb_Employe_Name = new System.Windows.Forms.TextBox();
            this.cmb_Department = new System.Windows.Forms.ComboBox();
            this.gb_Gender = new System.Windows.Forms.GroupBox();
            this.rb_Female = new System.Windows.Forms.RadioButton();
            this.rb_Male = new System.Windows.Forms.RadioButton();
            this.gb_Shift = new System.Windows.Forms.GroupBox();
            this.rb_Night = new System.Windows.Forms.RadioButton();
            this.rb_Evening = new System.Windows.Forms.RadioButton();
            this.rb_Morning = new System.Windows.Forms.RadioButton();
            this.btn_Submit = new System.Windows.Forms.Button();
            this.btn_Reset = new System.Windows.Forms.Button();
            this.lbl_Output = new System.Windows.Forms.Label();
            this.tb_Output = new System.Windows.Forms.TextBox();
            this.pnl_.SuspendLayout();
            this.gb_Gender.SuspendLayout();
            this.gb_Shift.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_
            // 
            this.pnl_.BackColor = System.Drawing.Color.RoyalBlue;
            this.pnl_.Controls.Add(this.lbl_Shri_Ram_Mechanics);
            this.pnl_.Location = new System.Drawing.Point(3, 1);
            this.pnl_.Name = "pnl_";
            this.pnl_.Size = new System.Drawing.Size(1316, 76);
            this.pnl_.TabIndex = 0;
            // 
            // lbl_Shri_Ram_Mechanics
            // 
            this.lbl_Shri_Ram_Mechanics.AutoSize = true;
            this.lbl_Shri_Ram_Mechanics.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Shri_Ram_Mechanics.ForeColor = System.Drawing.Color.White;
            this.lbl_Shri_Ram_Mechanics.Location = new System.Drawing.Point(463, 19);
            this.lbl_Shri_Ram_Mechanics.Name = "lbl_Shri_Ram_Mechanics";
            this.lbl_Shri_Ram_Mechanics.Size = new System.Drawing.Size(403, 40);
            this.lbl_Shri_Ram_Mechanics.TabIndex = 0;
            this.lbl_Shri_Ram_Mechanics.Text = "SHRIRAM MECHANICALS";
            // 
            // lbl_Employe_Name
            // 
            this.lbl_Employe_Name.AutoSize = true;
            this.lbl_Employe_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Employe_Name.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Employe_Name.Location = new System.Drawing.Point(255, 125);
            this.lbl_Employe_Name.Name = "lbl_Employe_Name";
            this.lbl_Employe_Name.Size = new System.Drawing.Size(145, 25);
            this.lbl_Employe_Name.TabIndex = 1;
            this.lbl_Employe_Name.Text = "Employe Name";
            this.lbl_Employe_Name.Click += new System.EventHandler(this.lbl_Employe_Name_Click);
            // 
            // lbl_Department
            // 
            this.lbl_Department.AutoSize = true;
            this.lbl_Department.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Department.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Department.Location = new System.Drawing.Point(255, 215);
            this.lbl_Department.Name = "lbl_Department";
            this.lbl_Department.Size = new System.Drawing.Size(113, 25);
            this.lbl_Department.TabIndex = 1;
            this.lbl_Department.Text = "Department";
            this.lbl_Department.Click += new System.EventHandler(this.lbl_Employe_Name_Click);
            // 
            // lbl_Gender
            // 
            this.lbl_Gender.AutoSize = true;
            this.lbl_Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Gender.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Gender.Location = new System.Drawing.Point(255, 297);
            this.lbl_Gender.Name = "lbl_Gender";
            this.lbl_Gender.Size = new System.Drawing.Size(77, 25);
            this.lbl_Gender.TabIndex = 1;
            this.lbl_Gender.Text = "Gender";
            this.lbl_Gender.Click += new System.EventHandler(this.lbl_Employe_Name_Click);
            // 
            // lbl_Preferred_Shift
            // 
            this.lbl_Preferred_Shift.AutoSize = true;
            this.lbl_Preferred_Shift.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Preferred_Shift.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Preferred_Shift.Location = new System.Drawing.Point(255, 383);
            this.lbl_Preferred_Shift.Name = "lbl_Preferred_Shift";
            this.lbl_Preferred_Shift.Size = new System.Drawing.Size(135, 25);
            this.lbl_Preferred_Shift.TabIndex = 1;
            this.lbl_Preferred_Shift.Text = "Preffered Shift";
            this.lbl_Preferred_Shift.Click += new System.EventHandler(this.lbl_Employe_Name_Click);
            // 
            // tb_Employe_Name
            // 
            this.tb_Employe_Name.BackColor = System.Drawing.Color.White;
            this.tb_Employe_Name.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Employe_Name.Font = new System.Drawing.Font("Nirmala Text", 10.2F, System.Drawing.FontStyle.Bold);
            this.tb_Employe_Name.Location = new System.Drawing.Point(472, 125);
            this.tb_Employe_Name.Multiline = true;
            this.tb_Employe_Name.Name = "tb_Employe_Name";
            this.tb_Employe_Name.Size = new System.Drawing.Size(580, 34);
            this.tb_Employe_Name.TabIndex = 1;
            // 
            // cmb_Department
            // 
            this.cmb_Department.BackColor = System.Drawing.Color.White;
            this.cmb_Department.Font = new System.Drawing.Font("Nirmala Text", 10.2F, System.Drawing.FontStyle.Bold);
            this.cmb_Department.FormattingEnabled = true;
            this.cmb_Department.Items.AddRange(new object[] {
            "Fittter",
            "Tester",
            "Counter",
            "Biller",
            "Casher",
            "Manager",
            "Cleaner"});
            this.cmb_Department.Location = new System.Drawing.Point(472, 211);
            this.cmb_Department.Name = "cmb_Department";
            this.cmb_Department.Size = new System.Drawing.Size(579, 31);
            this.cmb_Department.TabIndex = 2;
            this.cmb_Department.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // gb_Gender
            // 
            this.gb_Gender.BackColor = System.Drawing.Color.White;
            this.gb_Gender.Controls.Add(this.rb_Female);
            this.gb_Gender.Controls.Add(this.rb_Male);
            this.gb_Gender.Location = new System.Drawing.Point(473, 283);
            this.gb_Gender.Name = "gb_Gender";
            this.gb_Gender.Size = new System.Drawing.Size(579, 54);
            this.gb_Gender.TabIndex = 3;
            this.gb_Gender.TabStop = false;
            this.gb_Gender.Text = "Gender";
            // 
            // rb_Female
            // 
            this.rb_Female.AutoSize = true;
            this.rb_Female.Font = new System.Drawing.Font("Nirmala Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Female.Location = new System.Drawing.Point(346, 19);
            this.rb_Female.Name = "rb_Female";
            this.rb_Female.Size = new System.Drawing.Size(88, 27);
            this.rb_Female.TabIndex = 1;
            this.rb_Female.TabStop = true;
            this.rb_Female.Text = "Female";
            this.rb_Female.UseVisualStyleBackColor = true;
            this.rb_Female.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // rb_Male
            // 
            this.rb_Male.AutoSize = true;
            this.rb_Male.Font = new System.Drawing.Font("Nirmala Text", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Male.Location = new System.Drawing.Point(137, 19);
            this.rb_Male.Name = "rb_Male";
            this.rb_Male.Size = new System.Drawing.Size(70, 27);
            this.rb_Male.TabIndex = 0;
            this.rb_Male.TabStop = true;
            this.rb_Male.Text = "Male";
            this.rb_Male.UseVisualStyleBackColor = true;
            this.rb_Male.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // gb_Shift
            // 
            this.gb_Shift.BackColor = System.Drawing.Color.White;
            this.gb_Shift.Controls.Add(this.rb_Night);
            this.gb_Shift.Controls.Add(this.rb_Evening);
            this.gb_Shift.Controls.Add(this.rb_Morning);
            this.gb_Shift.Location = new System.Drawing.Point(473, 378);
            this.gb_Shift.Name = "gb_Shift";
            this.gb_Shift.Size = new System.Drawing.Size(181, 145);
            this.gb_Shift.TabIndex = 4;
            this.gb_Shift.TabStop = false;
            this.gb_Shift.Text = "Shift";
            // 
            // rb_Night
            // 
            this.rb_Night.AutoSize = true;
            this.rb_Night.Font = new System.Drawing.Font("Nirmala UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Night.Location = new System.Drawing.Point(20, 116);
            this.rb_Night.Name = "rb_Night";
            this.rb_Night.Size = new System.Drawing.Size(77, 27);
            this.rb_Night.TabIndex = 0;
            this.rb_Night.TabStop = true;
            this.rb_Night.Text = "Night";
            this.rb_Night.UseVisualStyleBackColor = true;
            this.rb_Night.CheckedChanged += new System.EventHandler(this.rb_Night_CheckedChanged);
            // 
            // rb_Evening
            // 
            this.rb_Evening.AutoSize = true;
            this.rb_Evening.Font = new System.Drawing.Font("Nirmala UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Evening.Location = new System.Drawing.Point(20, 68);
            this.rb_Evening.Name = "rb_Evening";
            this.rb_Evening.Size = new System.Drawing.Size(94, 27);
            this.rb_Evening.TabIndex = 0;
            this.rb_Evening.TabStop = true;
            this.rb_Evening.Text = "Evening";
            this.rb_Evening.UseVisualStyleBackColor = true;
            // 
            // rb_Morning
            // 
            this.rb_Morning.AutoSize = true;
            this.rb_Morning.Font = new System.Drawing.Font("Nirmala UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Morning.Location = new System.Drawing.Point(20, 19);
            this.rb_Morning.Name = "rb_Morning";
            this.rb_Morning.Size = new System.Drawing.Size(100, 27);
            this.rb_Morning.TabIndex = 0;
            this.rb_Morning.TabStop = true;
            this.rb_Morning.Text = "Morning";
            this.rb_Morning.UseVisualStyleBackColor = true;
            // 
            // btn_Submit
            // 
            this.btn_Submit.BackColor = System.Drawing.Color.LimeGreen;
            this.btn_Submit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Submit.Location = new System.Drawing.Point(473, 559);
            this.btn_Submit.Name = "btn_Submit";
            this.btn_Submit.Size = new System.Drawing.Size(127, 41);
            this.btn_Submit.TabIndex = 5;
            this.btn_Submit.Text = "Submit";
            this.btn_Submit.UseVisualStyleBackColor = false;
            this.btn_Submit.Click += new System.EventHandler(this.btn_Submit_Click);
            // 
            // btn_Reset
            // 
            this.btn_Reset.BackColor = System.Drawing.Color.OrangeRed;
            this.btn_Reset.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Reset.Location = new System.Drawing.Point(671, 559);
            this.btn_Reset.Name = "btn_Reset";
            this.btn_Reset.Size = new System.Drawing.Size(127, 41);
            this.btn_Reset.TabIndex = 6;
            this.btn_Reset.Text = "Reset";
            this.btn_Reset.UseVisualStyleBackColor = false;
            this.btn_Reset.Click += new System.EventHandler(this.btn_Reset_Click);
            // 
            // lbl_Output
            // 
            this.lbl_Output.AutoSize = true;
            this.lbl_Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Output.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Output.Location = new System.Drawing.Point(255, 647);
            this.lbl_Output.Name = "lbl_Output";
            this.lbl_Output.Size = new System.Drawing.Size(71, 25);
            this.lbl_Output.TabIndex = 1;
            this.lbl_Output.Text = "Output";
            this.lbl_Output.Click += new System.EventHandler(this.lbl_Employe_Name_Click);
            // 
            // tb_Output
            // 
            this.tb_Output.BackColor = System.Drawing.Color.White;
            this.tb_Output.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_Output.Font = new System.Drawing.Font("Nirmala Text", 10.2F, System.Drawing.FontStyle.Bold);
            this.tb_Output.Location = new System.Drawing.Point(472, 634);
            this.tb_Output.Multiline = true;
            this.tb_Output.Name = "tb_Output";
            this.tb_Output.Size = new System.Drawing.Size(579, 52);
            this.tb_Output.TabIndex = 7;
            // 
            // frm_Windows_Tools
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(1320, 727);
            this.Controls.Add(this.btn_Reset);
            this.Controls.Add(this.btn_Submit);
            this.Controls.Add(this.gb_Shift);
            this.Controls.Add(this.gb_Gender);
            this.Controls.Add(this.cmb_Department);
            this.Controls.Add(this.tb_Output);
            this.Controls.Add(this.tb_Employe_Name);
            this.Controls.Add(this.lbl_Output);
            this.Controls.Add(this.lbl_Preferred_Shift);
            this.Controls.Add(this.lbl_Gender);
            this.Controls.Add(this.lbl_Department);
            this.Controls.Add(this.lbl_Employe_Name);
            this.Controls.Add(this.pnl_);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_Windows_Tools";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Windows Tools";
            this.Load += new System.EventHandler(this.frm_Windows_Tools_Load);
            this.pnl_.ResumeLayout(false);
            this.pnl_.PerformLayout();
            this.gb_Gender.ResumeLayout(false);
            this.gb_Gender.PerformLayout();
            this.gb_Shift.ResumeLayout(false);
            this.gb_Shift.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_;
        private System.Windows.Forms.Label lbl_Shri_Ram_Mechanics;
        private System.Windows.Forms.Label lbl_Employe_Name;
        private System.Windows.Forms.Label lbl_Department;
        private System.Windows.Forms.Label lbl_Gender;
        private System.Windows.Forms.Label lbl_Preferred_Shift;
        private System.Windows.Forms.TextBox tb_Employe_Name;
        private System.Windows.Forms.ComboBox cmb_Department;
        private System.Windows.Forms.GroupBox gb_Gender;
        private System.Windows.Forms.RadioButton rb_Female;
        private System.Windows.Forms.RadioButton rb_Male;
        private System.Windows.Forms.GroupBox gb_Shift;
        private System.Windows.Forms.RadioButton rb_Night;
        private System.Windows.Forms.RadioButton rb_Evening;
        private System.Windows.Forms.RadioButton rb_Morning;
        private System.Windows.Forms.Button btn_Submit;
        private System.Windows.Forms.Button btn_Reset;
        private System.Windows.Forms.Label lbl_Output;
        private System.Windows.Forms.TextBox tb_Output;
    }
}

