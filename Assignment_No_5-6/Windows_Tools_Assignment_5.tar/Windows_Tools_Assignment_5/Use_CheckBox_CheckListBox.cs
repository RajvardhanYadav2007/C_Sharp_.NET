﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Tools_Assignment_5
{
    public partial class frm_Use_CheckBox_CheckListBox : Form
    {
        public frm_Use_CheckBox_CheckListBox()
        {
            InitializeComponent();
        }

        private void lbl_Employ_Registretion_System_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void gb_Hobbies_Enter(object sender, EventArgs e)
        {

        }

        private void btn_Submit_Click(object sender, EventArgs e)
        {
            string Res = "";
            bool Flag = false, lFlag = false;

            if (tb_Employe_Name.Text != "")
            {
                Res = tb_Employe_Name.Text + " is from department ";
                lbl_Employe_Name.Visible = false;
            }
            else
            {
                lbl_Employe_Name.Text = "Enter Employee Name";
                lbl_Employe_Name.Visible = true;

                Flag = true;
            }

            if (cmb_Department.SelectedIndex != -1)
            {
                Res += cmb_Department.Text + " is ";
                lbl_Department.Visible = false;
            }
            else
            {
                lbl_Department.Text = "Select Employee Department";
                lbl_Department.Visible = true;

                Flag = true;
            }

            if (rb_Male.Checked)
            {
                Res += rb_Male.Text + " Candidate, He Knows ";
                lbl_Gender.Visible = false;
            }
            else if (rb_Female.Checked)
            {
                Res += rb_Female.Text + " Candidate, She Knows ";
                lbl_Gender.Visible = false;
            }
            else
            {
                lbl_Gender.Text = "Select Gender";
                lbl_Gender.Visible = true;

                Flag = true;
            }

            if (cb_Marathi.Checked)
            {
                lbl_Known_Languages.Visible = false;
                lFlag = true;

                if (cb_Hindi.Checked == false && cb_French.Checked == false && cb_English.Checked == false)
                {
                    Res += cb_Marathi.Text + ". ";
                }
                else
                {
                    Res += cb_Marathi.Text + ", ";
                }
            }

            if (cb_Hindi.Checked)
            {
                lbl_Known_Languages.Visible = false;
                lFlag = true;

                if (cb_French.Checked == false && cb_English.Checked == false)
                {
                    Res += cb_Hindi.Text + ". ";
                }
                else
                {
                    Res += cb_Hindi.Text + ", ";
                }
            }

            if (cb_English.Checked)
            {
                lbl_Known_Languages.Visible = false;
                lFlag = true;

                if (cb_French.Checked == false)
                {
                    Res += cb_English.Text + ". ";
                }
                else
                {
                    Res += cb_English.Text + ", ";
                }
            }

            if (cb_French.Checked)
            {
                Res += cb_French.Text + ". ";
                lbl_Known_Languages.Visible = false;

                lFlag = true;
            }

            if (lFlag == false)
            {
                lbl_Known_Languages.Text = "Select at least 1 Known Language";
                lbl_Known_Languages.Visible = true;

                Flag = true;
            }

            //// LOOP For Hobbies
            int Cnt = clb_Hobbies.CheckedItems.Count;

            if (Cnt > 0)
            {
                Res += "Has hobbies as ";

                for (int i = 0; i < Cnt; i++)
                {
                    if (i < Cnt - 1)
                    {
                        Res += clb_Hobbies.CheckedItems[i] + ", ";
                    }
                    else
                    {
                        Res += clb_Hobbies.CheckedItems[i] + ".";
                    }
                }

                lbl_Hobbies.Visible = false;
            }
            else
            {
                lbl_Hobbies.Text = "Select at Least 1 Hobby";
                lbl_Hobbies.Visible = true;

                Flag = true;
            }

            if (Flag == false)
            {
                lbl_Output.Text = Res;
                lbl_Output.Visible = true;
            }
            else
            {
                lbl_Output.Text = "";
                lbl_Output.Visible = false;
            }
        }

        private void frm_Use_CheckBox_CheckListBox_Load(object sender, EventArgs e)
        {
            lbl_Employe_Name.Visible = false;
            lbl_Department.Visible = false;
            lbl_Gender.Visible = false;
            lbl_Known_Languages.Visible = false;
            lbl_Hobbies.Visible = false;

            tb_Output.Clear();

            cmb_Department.Items.Add("HR");
            cmb_Department.Items.Add("Sales");
            cmb_Department.Items.Add("IT");
            cmb_Department.Items.Add("Finance");
        }

        private void cb_English_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cb_French_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void cb_Marathi_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void clb_Hobbies_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            tb_Employe_Name.Clear();

            cmb_Department.SelectedIndex = -1;

            rb_Male.Checked = false;
            rb_Female.Checked = false;

            cb_Marathi.Checked = false;
            cb_Hindi.Checked = false;
            cb_French.Checked = false;
            cb_English.Checked = false;

            for (int i = 0; i < clb_Hobbies.Items.Count; i++)
            {
                clb_Hobbies.SetItemChecked(i, false);
            }

            clb_Hobbies.ClearSelected();

            lbl_Department.Visible = false;
            lbl_Gender.Visible = false;
            lbl_Hobbies.Visible = false;
            lbl_Known_Languages.Visible = false;
            lbl_Employe_Name.Visible = false;
            lbl_Output.Visible = false;

        }

        private void lbl_Output_Click(object sender, EventArgs e)
        {

        }

        
    }
}
