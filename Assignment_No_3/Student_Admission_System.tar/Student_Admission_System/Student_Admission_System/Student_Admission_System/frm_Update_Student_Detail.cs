﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Student_Admission_System
{
    public partial class frm_Update_Student_Detail : Form
    {
        public frm_Update_Student_Detail()
        {
            InitializeComponent();
        }

        SqlConnection Fcon = new SqlConnection(@"Data Source=LAPTOP-CT0EUGGN;Initial Catalog=SGM_College_Admission_System;Integrated Security=True");

        void FconStart()
        {
            if (Fcon.State == ConnectionState.Closed)
            {
                Fcon.Open();
            }
        }

        void FConStop()
        {
            if (Fcon.State == ConnectionState.Open)
            {
                Fcon.Close();
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            if (tb_Roll_No.Text == "")
            {
                MessageBox.Show("Enter Roll Number");
                tb_Roll_No.Focus();
                return;
            }

            FconStart();

            SqlCommand cmd = new SqlCommand("Select * From [Table] Where Roll_No=@RNo", Fcon);
            cmd.Parameters.Add("@RNo", SqlDbType.Int).Value = Convert.ToInt32(tb_Roll_No.Text);

            SqlDataReader DR = cmd.ExecuteReader();

            if (DR.Read())
            {
                tb_User_Name.Text = DR["User_Name"].ToString();
                tb_Mobile_No.Text = DR["Mobile_No"].ToString();
                dtp_DOB.Value = Convert.ToDateTime(DR["DOB"]);
                cmb_Course.Text = DR["Course"].ToString();
            }
            else
            {
                MessageBox.Show("Student Not Found");
            }

            DR.Close();
            FConStop();
        }

        private void btn_Update_Click(object sender, EventArgs e)
        {
            if (tb_Roll_No.Text == "" || tb_User_Name.Text == "" || tb_Mobile_No.Text == "" || cmb_Course.Text == "")
            {
                MessageBox.Show("Fill All Information");
                return;
            }

            FconStart();

            SqlCommand cmd = new SqlCommand("Update [Table] Set User_Name=@UN, Mobile_No=@MN, DOB=@DOB, Course=@Course Where Roll_No=@RNo", Fcon);

            cmd.Parameters.AddWithValue("@UN", tb_User_Name.Text.Trim());
            cmd.Parameters.AddWithValue("@MN", tb_Mobile_No.Text.Trim());
            cmd.Parameters.AddWithValue("@DOB", dtp_DOB.Value.Date);
            cmd.Parameters.AddWithValue("@Course", cmb_Course.Text);
            cmd.Parameters.AddWithValue("@RNo", Convert.ToInt32(tb_Roll_No.Text));

            int Count = cmd.ExecuteNonQuery();

            FConStop();

            if (Count == 1)
            {
                MessageBox.Show("Student Details Updated Successfully");
            }
            else
            {
                MessageBox.Show("Roll Number Not Found");
            }
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            tb_Roll_No.Clear();
            tb_User_Name.Clear();
            tb_Mobile_No.Clear();
            cmb_Course.SelectedIndex = -1;
            dtp_DOB.Value = DateTime.Now;
            tb_Roll_No.Focus();
        }
       

        private void btn_Logout_Click(object sender, EventArgs e)
        {
            frm_Student_Login obj = new frm_Student_Login();
            obj.Show();
            this.Hide();
        }

        private void btn_Add_New_Student_Click(object sender, EventArgs e)
        {
            frm_Add_Student_Details obj = new frm_Add_Student_Details();
            obj.Show();
            this.Hide();
        }

        private void btn_Search_Student_Click(object sender, EventArgs e)
        {
            frm_Search_Student_Detail obj = new frm_Search_Student_Detail();
            obj.Show();
            this.Hide();
        }

        private void btn_Student_List_Click(object sender, EventArgs e)
        {
            frm_Student_List obj = new frm_Student_List();
            obj.Show();
            this.Hide();
        }

        private void frm_Update_Student_Detail_Load(object sender, EventArgs e)
        {
            tb_Roll_No.KeyPress += Only_Number;
            tb_Mobile_No.KeyPress += Only_Number;
            tb_User_Name.KeyPress += Only_Text;

        }
        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) ||
                  e.KeyChar == (char)Keys.Back ||
                  e.KeyChar == (char)Keys.Space))
            {
                e.Handled = true;
            }
        }

        private void Only_Number(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) ||
                  e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }
    }
}