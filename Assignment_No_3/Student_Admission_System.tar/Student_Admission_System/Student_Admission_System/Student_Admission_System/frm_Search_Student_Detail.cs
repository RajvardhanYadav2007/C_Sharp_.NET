﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Student_Admission_System
{
    public partial class frm_Search_Student_Detail : Form
    {
        public frm_Search_Student_Detail()
        {
            InitializeComponent();
        }

        SqlConnection Fcon = new SqlConnection(
        @"Data Source=LAPTOP-CT0EUGGN;Initial Catalog=SGM_College_Admission_System;Integrated Security=True");

        void FconStart()
        {
            if (Fcon.State != ConnectionState.Open)
            {
                Fcon.Open();
            }
        }

        void FConStop()
        {
            if (Fcon.State != ConnectionState.Closed)
            {
                Fcon.Close();
            }
        }

        private void btn_Search_Click(object sender, EventArgs e)
        {
            if (tb_Roll_No.Text == "")
            {
                MessageBox.Show("Enter Roll Number");
                return;
            }

            FconStart();

            SqlCommand cmd = new SqlCommand();

            cmd.Connection = Fcon;

            cmd.CommandText = "Select * from [Table] where Roll_No=@RNo";

            cmd.Parameters.Add("@RNo", SqlDbType.Int).Value =
            Convert.ToInt32(tb_Roll_No.Text);

            SqlDataReader DR = cmd.ExecuteReader();

            if (DR.Read())
            {
                tb_User_Name.Text = DR["User_Name"].ToString();
                tb_Mobile_No.Text = DR["Mobile_No"].ToString();
                dtp_DOB.Text = DR["DOB"].ToString();
                cmb_Course.Text = DR["Course"].ToString();
            }
            else
            {
                MessageBox.Show("Invalid Roll Number", "No Such Student Found");
            }

            DR.Close();

            FConStop();
        }
       

        private void btn_Refresh_Click(object sender, EventArgs e)
        {
            tb_Roll_No.Clear();
            tb_User_Name.Clear();
            tb_Mobile_No.Clear();
            cmb_Course.SelectedIndex = -1;
            dtp_DOB.Text = "";
            tb_Roll_No.Focus();
        }

        private void btn_Logout_Click(object sender, EventArgs e)
        {
            frm_Student_Login obj = new frm_Student_Login();
            obj.Show();
            this.Hide();
        }

        private void btn_Add_New_Student_Click(object sender, EventArgs e)
        {
            frm_Add_Student_Details obj = new frm_Add_Student_Details();
            obj.Show();
            this.Hide();
        }

        private void btn_Update_Student_Click(object sender, EventArgs e)
        {
            frm_Update_Student_Detail obj = new frm_Update_Student_Detail();
            obj.Show();
            this.Hide();
        }

        private void btn_Student_List_Click(object sender, EventArgs e)
        {
            frm_Student_List obj = new frm_Student_List();
            obj.Show();
            this.Hide();
        }

        private void frm_Search_Student_Detail_Load(object sender, EventArgs e)
        {
            tb_Roll_No.KeyPress += Only_Number;
            tb_Mobile_No.KeyPress += Only_Number;
            tb_User_Name.KeyPress += Only_Text;
        }
        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) ||
                  e.KeyChar == (char)Keys.Back ||
                  e.KeyChar == (char)Keys.Space))
            {
                e.Handled = true;
            }
        }

        private void Only_Number(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) ||
                  e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }
    }
}