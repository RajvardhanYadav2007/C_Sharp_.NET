﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Student_Admission_System
{
    public partial class frm_Student_Login : Form
    {
        public frm_Student_Login()
        {
            InitializeComponent();
        }

        SqlConnection FCon = new SqlConnection(@"Data Source=LAPTOP-CT0EUGGN;Initial Catalog=SGM_College_Admission_System;Integrated Security=True");

        void FConstart()
        {
            if (FCon.State != ConnectionState.Open)
            {
                FCon.Open();
            }
        }

        void FConStop()
        {
            if (FCon.State != ConnectionState.Closed)
            {
                FCon.Close();
            }
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            FConstart();

            SqlCommand cmd = new SqlCommand();

            cmd.Connection = FCon;  

            cmd.CommandText = "Select Count(*) from dbo.Login_Details where [Student ID]=@SId And Password=@Pw";

            cmd.Parameters.Add("@SId", SqlDbType.NVarChar).Value = tb_Student_ID.Text.Trim();
            cmd.Parameters.Add("@Pw", SqlDbType.NVarChar).Value = tb_Password.Text.Trim();

            int Cnt = Convert.ToInt32(cmd.ExecuteScalar());

            if (Cnt > 0)
            {
                MessageBox.Show("Login Successful", "SUCCESS");

                frm_Add_Student_Details obj = new frm_Add_Student_Details();
                obj.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Incorrect Username or Password", "Failure");
            }
        }

        private void frm_Student_Login_Load(object sender, EventArgs e)
        {

        }

        private void lbl_Login_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Instruction_Click(object sender, EventArgs e)
        {

        }
    }
}
