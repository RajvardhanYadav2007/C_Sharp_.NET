﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Student_Admission_System
{
    public partial class frm_Student_List : Form
    {
        public frm_Student_List()
        {
            InitializeComponent();
        }

        SqlConnection Fcon = new SqlConnection(
            @"Data Source=LAPTOP-CT0EUGGN;Initial Catalog=SGM_College_Admission_System;Integrated Security=True");

        void FConStart()
        {
            if (Fcon.State != ConnectionState.Open)
            {
                Fcon.Open();
            }
        }

        void FConClose()
        {
            if (Fcon.State != ConnectionState.Closed)
            {
                Fcon.Close();
            }
        }

        void FBindGrid()
        {
            FConStart();
            SqlDataAdapter SDA = new SqlDataAdapter(
                "Select * From [Table]", Fcon);

            DataTable DT = new DataTable();

            SDA.Fill(DT);

            dataGridView1.DataSource = DT;

            FConClose();
        }

        private void frm_Student_List_Load(object sender, EventArgs e)
        {
            FBindGrid();
        }

        private void btn_Logout_Click(object sender, EventArgs e)
        {
            frm_Student_Login obj = new frm_Student_Login();
            obj.Show();
            this.Hide();
        }

        private void btn_Search_Student_Click(object sender, EventArgs e)
        {
            frm_Search_Student_Detail obj = new frm_Search_Student_Detail();
            obj.Show();
            this.Hide();
        }

        private void btn_Update_Student_Click(object sender, EventArgs e)
        {
            frm_Update_Student_Detail obj = new frm_Update_Student_Detail();
            obj.Show();
            this.Hide();
        }

        private void btn_Add_New_Student_Click(object sender, EventArgs e)
        {
            frm_Add_Student_Details obj = new frm_Add_Student_Details();
            obj.Show();
            this.Hide();
        }

        private void lbl_student_List_Click(object sender, EventArgs e)
        {

        }

        private void btn_Update_Student_Click_1(object sender, EventArgs e)
        {
            frm_Update_Student_Detail obj = new frm_Update_Student_Detail();
            obj.Show();
            this.Hide();


        }
    }
}