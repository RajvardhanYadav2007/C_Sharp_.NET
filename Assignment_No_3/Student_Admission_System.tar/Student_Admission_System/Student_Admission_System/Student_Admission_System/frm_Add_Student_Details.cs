﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Student_Admission_System
{
    public partial class frm_Add_Student_Details : Form
    {
        public frm_Add_Student_Details()
        {
            InitializeComponent();
        }
        SqlConnection Fcon = new SqlConnection(@" Data Source=LAPTOP-CT0EUGGN;Initial Catalog=SGM_College_Admission_System;Integrated Security=True ");

        void FconStart()
        {
            if( Fcon.State != ConnectionState.Open)
            {
                Fcon.Open();
            }
        }
        void FConStop()
        {
            if(Fcon.State != ConnectionState.Closed)
            {
                Fcon.Close();
            }
        }
        void Clear_Control()
        {
            tb_Roll_No.Clear();
            tb_User_Name.Clear();
            tb_Mobile_No.Clear();
            cmb_Course.SelectedIndex = -1;
            dtp_DOB.Text = "06/02/2007";
        }
        

        private void btn_Logout_Click(object sender, EventArgs e)
        {
            frm_Student_Login obj = new frm_Student_Login();
            obj.Show();
            this.Hide();
        }

        private void btn_Search_Student_Click(object sender, EventArgs e)
        {
            frm_Search_Student_Detail obj = new frm_Search_Student_Detail();
            obj.Show();
            this.Hide();
        }

        private void btn_Update_Student_Click(object sender, EventArgs e)
        {
            frm_Update_Student_Detail obj = new frm_Update_Student_Detail();
            obj.Show();
            this.Hide();
        }

        private void btn_Student_List_Click(object sender, EventArgs e)
        {
            frm_Student_List obj = new frm_Student_List();
            obj.Show();
            this.Hide();
        }

        private void frm_Add_Student_Details_Load(object sender, EventArgs e)
        {

        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            FconStart();

            if (tb_Roll_No.Text != "" &&
                tb_User_Name.Text != "" &&
                tb_Mobile_No.Text != "" &&
                cmb_Course.Text != "")
            {
                SqlCommand Cmd = new SqlCommand();

                Cmd.CommandText ="Insert Into [Table](Roll_No,User_Name,Mobile_No,Course,DOB) Values(@RNO,@UNm,@MNo,@Cr,@DB)";

                Cmd.Connection = Fcon;

                Cmd.Parameters.Add("@RNO", SqlDbType.Int).Value =
                    Convert.ToInt32(tb_Roll_No.Text);

                Cmd.Parameters.Add("@UNm", SqlDbType.VarChar).Value =
                    tb_User_Name.Text;

                Cmd.Parameters.Add("@MNo", SqlDbType.VarChar).Value =
                    tb_Mobile_No.Text;

                Cmd.Parameters.Add("@Cr", SqlDbType.VarChar).Value =
                    cmb_Course.Text;

                Cmd.Parameters.Add("@DB", SqlDbType.Date).Value =
                    dtp_DOB.Value;

                Cmd.ExecuteNonQuery();

                MessageBox.Show("Student Detail Saved Successfully", "SUCCESS");

                Clear_Control();
            }
            else
            {
                MessageBox.Show("Incomplete Info", "Not Saved");
            }

            FConStop();
        }

        private void btn_Refresh_Click(object sender, EventArgs e)
        {

            tb_Roll_No.Clear();

            tb_User_Name.Clear();

            tb_Mobile_No.Clear();


            cmb_Course.SelectedIndex = -1;


            dtp_DOB.Text = "";


            tb_Roll_No.Focus();

        }

        private void tb_Roll_No_TextChanged(object sender, EventArgs e)
        {
            tb_Roll_No.KeyPress += Only_Number;
            tb_Mobile_No.KeyPress += Only_Number;
            tb_User_Name.KeyPress += Only_Text;
        }
        private void Only_Text(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsLetter(e.KeyChar) ||
                  e.KeyChar == (char)Keys.Back ||
                  e.KeyChar == (char)Keys.Space))
            {
                e.Handled = true;
            }
        }

        private void Only_Number(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsDigit(e.KeyChar) ||
                  e.KeyChar == (char)Keys.Back))
            {
                e.Handled = true;
            }
        }

    }
}
